package projetojava;

import java.util.Scanner;
//Desenvolva um algoritmo que efetue a leitura de dois valores inteiros e apresente a
//diferença entre o maior e o menor. E se essa diferença é maior que 1000, par ou ímpar.

public class Valores {
	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);

//Entrada
		System.out.println("Digite o primeiro numero");
		int numero1 = teclado.nextInt();

		System.out.println("Digite o segundo numero");
		int numero2 = teclado.nextInt();

		int diferenca;

		// Resolução/Saída

		if (numero1 > numero2) {
			diferenca = numero2 - numero1;

		} else  {
			diferenca = numero2 - numero1;
		}
		System.out.println("diferença = " + diferenca);
		if (diferenca > 100) {

			System.out.println("A diferença entre o maior e o menor. E se essa diferença é maior que 1000");
		} else {
			System.out.println("A diferença entre os numeros não é maior que 1000");
		}
		if (diferenca % 2 == 0) {
			System.out.println("A diferença é par");

		} else {
			System.out.println("A diferença impar");
		}
	}
}
