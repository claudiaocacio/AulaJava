package projetojava;
import java.util.Scanner;

public class Exercicio03 {
	
public static void main(String[] args) {
	Scanner teclado = new Scanner(System.in);

	System.out.println("Digite o primeiro numero: ");
	float numeroA = teclado.nextFloat();
	
	System.out.println("Digite o segundo numero: ");
	float numeroB = teclado.nextFloat();
	
	System.out.println("O resultado é = " + (numeroA - numeroB));
	
	}

}