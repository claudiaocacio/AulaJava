package projetojava;

import java.util.Scanner;
//Desenvolva um algoritmo que efetue a leitura de um valor inteiro e informe se o mesmo é maior que 10.

public class Maior10 {
	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);

		// Entrada

		System.out.println("Digite um numero");
		int numero = teclado.nextInt();

		// Resolução saida
		if (numero > 10) {
			System.out.println(numero + " É maior que 10");
		} else if (numero < 10) {
			System.out.println("Não é maior que 10");
		} else if (numero == 10) {
			System.out.println("É igual a 10");
		}
	}
}
