package projetojava;

import java.util.Scanner;

public class MediaIdades {
	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		int idade;
		int somaIdades = 0;
		double quantidadeIdades = 0;
		do {
			System.out.println("Informe uma idade: ");
			idade = teclado.nextInt();
			if (idade > 0) {
				somaIdades = somaIdades + idade;
				quantidadeIdades++;
			}
		}
		
		while (idade > 0); 
		double media = somaIdades / quantidadeIdades;
			System.out.println("media =" + media);
			
			

			}
		}
	

