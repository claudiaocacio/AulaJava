package projetojava;

import java.util.Scanner;

public class ImparPar {
	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		System.out.println("Digite o primeiro numero");
		int numero1 = teclado.nextInt();
		System.out.println("digite o segundo numero");
		int numero2 = teclado.nextInt();
System.out.println("É par ou impar" + numero1 + "e" + numero2); 
for (int i = numero1; i <= numero2; i++) {
	if (i % 2 == 0) {
		System.out.println(i + " É par");
	}else {
		System.out.println(i + " É impar");
	}
}
	}
}
