package projetojava;

import java.util.Scanner;
//4. Faça um programa que receba dois números e mostre o menor.

public class MenorMaior {
	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);

		// Entrada

		System.out.println("Digite o primeiro numero");
		double numero1 = teclado.nextDouble();
		System.out.println("Digite o segundo numero");
		double numero2 = teclado.nextDouble();

		if (numero1 < numero2) {
			System.out.println("O menor numero é: " + numero1);

		} else if (numero2 < numero1) {
			System.out.println("O menor numero é:" + numero2);

		}

	}

}
