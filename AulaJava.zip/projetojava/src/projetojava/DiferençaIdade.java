package projetojava;

import java.util.Scanner;
//Desenvolva um algoritmo que que efetue a leitura de dois nomes e duas idades,
//depois informa qual é a pessoa mais velha e a diferença das idades.

public class DiferençaIdade {
	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		// Entradas
		System.out.println("Digite o primeiro nome");
		String nome1 = teclado.nextLine();
		System.out.println("Digite a primeira idade" + nome1 + ": ");
		int idade1 = teclado.nextInt();
		System.out.println("Digite o segundo nome");
		String nome2 = teclado.nextLine();
		System.out.println("Digite a segunda idade " + nome2 + ": ");
		int idade2 = teclado.nextInt();

		System.out.println("Digite a idade " + nome2 + ": ");
		if (idade1 > idade2) {
			System.out.println(nome1 + "É mais velho que" + nome2);
			System.out.println("A diferença de idade é de" + (idade1 - idade2) + "anos");
			System.out.println("É mais velho que" + nome1);
			System.out.println("Adiferença de idade é de" + (idade2 - idade1) + "anos");

		}

	}
}
