public class OperadoresAritmeticos {

	public static void main(String[] args) {
		int numeroA = 10;
		int numeroB = 6;
		
		System.out.println("soma (String) = " + numeroA + numeroB);
		System.out.println("soma (Numero) = " + (numeroA + numeroB));
		
		System.out.println("subtracao = " + (numeroA - numeroB));
		
		System.out.println("multiplicacao = " + numeroA * numeroB);
		
		double numeroC = 6.0;
		System.out.println("divisao = " + numeroA / numeroB);
		System.out.println("divisao = " + numeroA / numeroC);
		
		System.out.println("resto = " + numeroA % numeroB);
		
		System.out.println("incremento = " + numeroA++);
		System.out.println("incremento = " + ++numeroA);
		System.out.println("incremento = " + numeroA);
		System.out.println("decremento = " + --numeroB);
	}
}