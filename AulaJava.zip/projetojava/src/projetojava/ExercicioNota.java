package projetojava;

import java.util.Scanner;

//Faça um programa para ler o nome, 3 notas de um aluno e mostre a média e a mensagem conforme a tabela abaixo:
//a. a) Inferior a 5,0 – "Reprovado"
//b. b) De 5,1 a 6,9 – "Recuperação"
//c. c) De 7,0 a 10 – "Aprovado
public class ExercicioNota {
	public static void main(String[] args) {

		Scanner teclado = new Scanner(System.in);

		// Entradas

		System.out.println("Digite o nome do aluno");
		String nome = teclado.nextLine();
		System.out.println("Digite a primeira nota");
		int nota1 = teclado.nextInt();
		System.out.println("Digite a segunda nota");
		int nota2 = teclado.nextInt();
		System.out.println("Digite a terceira nota");
		int nota3 = teclado.nextInt();

		// Resolução

		int media = (nota1 + nota2 + nota3) / 3;
		System.out.println("A media do aluno" + nome + "é: " + media);

		// Saída

		if (media < 5) {
			System.out.println("REPROVADO");
		} else if (media >= 5.1 && media <= 6.9) {
			System.out.println("RECUPERAÇÃO");
		} else if (media >= 7.0 && media <= 10) {
			System.out.println("APROVADO");

		}
	}
}
