package projetojava;

import java.util.Scanner;
//Faça um programa que receba dois números e execute uma das operações listadas a seguir.
//a. O primeiro número mais o dobro segundo número.
//b. Informar 25% do primeiro valor informado.
//c. Aumentar em 20% o segundo valor informado
//Se for digitada uma opção inválida, mostre mensagem que a opção escolhida é inválida.

public class QuintoExercicio {
	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);

		// Entradas
		System.out.println("Digite o primeiro numero");
		int numero1 = teclado.nextInt();

		System.out.println("Digite o segundo numero");
		int numero2 = teclado.nextInt();

		teclado.nextLine();
		// Resolução
		System.out.println("Digite uma letra: ");
		String letra = teclado.nextLine();

		switch (letra) {
		case "a":

			double resultadoA = numero1 + (2 * numero2);
			System.out.println("Resultado (primeiro número + dobro do segundo número): " + resultadoA);
			break;

		case "b":

			double resultadoB = numero1 * 0.25;

			System.out.println("Resultado  (Informar 25% do primeiro valor informado): ");
			break;

		case "c":

			double resultadoC = numero2 + 0.20;

			System.out.println("Resultado (Aumentar em 20% o segundo valor informado)");
			break;

		default:
			System.out.println("Opção invalida!");
		}

	}
}
