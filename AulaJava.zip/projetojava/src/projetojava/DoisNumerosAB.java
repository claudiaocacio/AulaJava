package projetojava;

import java.util.Scanner;

public class DoisNumerosAB {
	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		System.out.println("Digite o primeiro numero");
		int numeroA = teclado.nextInt();
		System.out.println("Digite o segundo numero");
		int numeroB = teclado.nextInt();
		// Entrada
		System.out.println("numeros entre" + numeroA + "e" + numeroB + "(inclusive):");

		for (int i = numeroA; i <= numeroB; i++) {
			System.out.println(i);

		}

	}
}
