package projetojava;

import java.util.Scanner;

//Faça um programa que receba a idade de uma pessoa e mostre a mensagem com qual categoria ela se encontra:
//a. 10-14 infantil
//b. 15-17 juvenil
//c. 18-59 adulto
//d. maior que 60 terceira idade
public class ExercicioIdade {
	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);

		// Entradas

		System.out.println("Digite sua idade");
		int idade = teclado.nextInt();
		// Resolução
		if (idade < 14) {
			System.out.println("é INFANTIL");
		} else if (idade >= 10 && idade <= 14) {
			System.out.println("É INFNTIL");
		} else if (idade >= 15 && idade <= 17) {
			System.out.println("É JUVELNIL");
		} else if (idade >= 18 && idade <= 59) {
			System.out.println("É ADULTO");
			if (idade > 60) {
				System.out.println("TERCEIRA IDADE");
			}
		}
	}

}
