package projetojava;

import java.util.Scanner;
//Faça um algoritmo que leia um no inteiro e mostre uma mensagem indicando se este é positivo ou negativo.

public class PositivoNegativo {
	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);

		// Entrada/Saída
		System.out.println("Digite um numero inteiro");
		int numero = teclado.nextInt();
		if (numero > 0) {
			System.out.println("O numero é POSITIVO");
		} else if (numero < 0) {
			System.out.println("O numero é NEGATIVO");
		} else {
			System.out.println("O numero é ZERO");
		}
	}
}
