package projetojava;
import java.util.Scanner;

public class Exercicio05 {
	
public static void main(String[] args) {
	Scanner teclado = new Scanner(System.in);

	System.out.println("Digite um numero intero: ");
	float numeroA = teclado.nextFloat();
	
	System.out.println("Digite o segundo numero inteiro: ");
	float numeroB = teclado.nextFloat();
	
	System.out.println("O resultado é:  " + (numeroA / numeroB));
	
	}

}