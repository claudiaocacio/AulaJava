package projetojava;
import java.util.Scanner;
public class Idade1000 {
	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		int somaidade = 0;
		int conta = 1;

		while (somaidade < 1000){
		System.out.println("Digite a primeira idade" + conta);
		int idade = teclado.nextInt();
		System.out.println(somaidade += idade );
		
		}
	}

}
