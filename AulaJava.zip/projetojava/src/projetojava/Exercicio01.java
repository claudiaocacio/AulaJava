package projetojava;
import java.util.Scanner;

public class Exercicio01 {
	
public static void main(String[] args) {
	Scanner teclado = new Scanner(System.in);

	System.out.println("Digite um numero: ");
	float numeroA = teclado.nextFloat();
	
	System.out.println("Digite um numero: ");
	float numeroB = teclado.nextFloat();
	
	System.out.println("soma (Numero) = " + (numeroA + numeroB));
	
	}

}
