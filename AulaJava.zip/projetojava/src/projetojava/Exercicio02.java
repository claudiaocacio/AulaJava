package projetojava;
	import java.util.Scanner;

		public class Exercicio02 {
			public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);

		System.out.println("Digite o salario do marido: ");
		double salario1 = teclado.nextDouble();
		System.out.println("Digite o salario da esposa: ");
		double salario2 = teclado.nextDouble();
		double soma = (salario1 + salario2 );
		System.out.println("O total dos salários de sua família é de  = " + soma);


		
	}

}
