import java.util.Scanner;

public class MediaPonderada {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		// Entradas
		System.out.println("Digite a nota 1: ");
		double nota1 = teclado.nextDouble();
		
		System.out.println("Digite a nota 2: ");
		double nota2 = teclado.nextDouble();
		
		System.out.println("Digite a nota 3: ");
		double nota3 = teclado.nextDouble();

		
		// Resolu��o
		double media = (nota1 + nota2 + nota3 + nota4) / 4;
		
		// Sa�das
		System.out.println("M�dia = " + media);
		
		teclado.close();